﻿using UnityEngine;

namespace Sourav.Utilities.Scripts.Utilities
{
    public enum SingletonTypes
    {
        None,
        ExportHelper,
        CoreEngine,
        OrientationManager,
    }
}
